<div class="btn btn-default btn-block">
<footer> Design by <font color="red">&hearts;</font> <a href="/form design/developer/dev.php">Sedenu Aloaye Charles</a> &copy; 2017</footer>
</div></html>