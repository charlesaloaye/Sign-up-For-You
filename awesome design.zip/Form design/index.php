              
		<!--calling header -->
		<?php include"Header.php"?>
			<body>
    <div class="container">
      <div class="row">
        <div class="col-md-10" align="center">
          <div class="col-md-10">
        </div>

     <div class="panel panel-default">

			<form class="form-horizontal" method="post" role="form" action="">
	
		<!--developer image@me -->
               <a href="http://fb.com/Sedenu.charles"><img src="developer/developer.jpg" alt="Sedenu Aloaye Charles@developer" class="img-circle" height="120" width="120"></a>
                
                <div class="form-group">
               
		<!-- username -->
                <div class="form-group has-user has-feedback">
			<label for="username" class="control-label col-sm-3"></label>
			<div class="col-sm-12">
			<input type="text" name="user" id="username"  placeholder="Login name" class="form-control">
      <span class="glyphicon glyphicon-user form-control-feedback"></span>
			</div>
			</div>
			
			
		<!-- user email Address -->
     <div class="form-group has-envelope has-feedback">
			<label for="email" class="control-label col-sm-3"></label>
			
			<div class="col-sm-12">
			<input type="email" name="email" id="email" placeholder="Login Email" class="form-control" required>
			<span class="glyphicon glyphicon-envelope form-control-feedback">
      </span>
			</div>
			</div>
			
			
		<!--user phone number -->
			
			   <div class="form-group has-earphone has-feedback">
			
			<label for="phone" class="control-label col-sm-3"></label>
			<div class="col-sm-12">
			
			<input type="text" name="phone" id="phone" placeholder="Login Phone " class="form-control">
			<span class="glyphicon glyphicon-earphone form-control-feedback">
      </span>
			</div>
			</div>
			
		<!--user country -->
			
			   <div class="form-group has-map-marker has-feedback">
			<label for="country" class="control-label col-sm-3"></label>
			<div class="col-sm-12">
			<input type="text" name="country" id="country" placeholder="Country" class="form-control">
			<span class="glyphicon glyphicon-map-marker form-control-feedback">
      </span>
			</div>
			</div>
			
		<!--user password -->
			
			   <div class="form-group has-pencil has-feedback">
			<label for="pass" class="control-label col-sm-3"></label>
			<div class="col-sm-12">
			<input type="password" name="pss" id="pass" placeholder="Login Password" class="form-control" required>
			<span class="glyphicon glyphicon-pencil form-control-feedback">
      </span>
			</div>
			</div>
			
		<!--message for developer -->
    <div class="form-group has-bullhorn has-feedback">
			<label for="mfadmin" class="control-label col-sm-3">
	</label>
			<div class="col-sm-12">
			<input type="textarea" name="message" id="mfadmin" placeholder="Message Admin"  class="form-control">
			<span class="glyphicon glyphicon-bullhorn form-control-feedback">
      </span>
			</div>
			</div
      <p class="text-left"><a href="http://fb.com/Sedenu.tk">Already a member?</a></p>
 
			<input type="submit" name="submit" id="register" placeholder="Login name" value="Sign Up" class="btn btn-success btn-block"><hr/><div align="center">
			
                <p class="blue" align="center">Sign up with</p>

                <p><a href="http://fb.com/Sedenu.charles" class="fa fa-facebook-f fa-sm"></a> <i class="fa fa-google-plus fa-sm"></i><i class="fa fa-twitter fa-sm"></i></p></div>
			</form>
			</div></div></div></div>
		<!--calling footer -->
			<?php include("footer.php");?>
				
		<!--loading fast sake -->
			
    <script src="build/js/jquery.min.js"></script>
    <script src="build/js/bootstrap.min.js"></script>
    <script>
		 </body>
			