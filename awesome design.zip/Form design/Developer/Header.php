<!DOCTYPE html>
<html lang="en"><head>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Best Form for your Project</title>
		<meta name="description" content="Best Form form your project">
		<meta name="keywords" content="">
		<meta name="author" content="Sedenu.A.Charles">
		<meta charset="UTF-8">		

    <!-- Bootstrap core CSS -->
    <link href="build/css/bootstrap.min.css" rel="stylesheet">
    <link href="build/css/font-awesome.min.css" rel="stylesheet">
    <link href="build/css/style.css" rel="stylesheet">
			
			</head>
			