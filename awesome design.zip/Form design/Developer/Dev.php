<?php include("Header.php");?>
<?php
$title="<div class='btn btn-success'><h3>About Me</h3></div>";
$devimg='<center><img src="developer.jpg" alt="Sedenu Aloaye Charles@developer" class="img-thumbnail" height="170" width="170"><center>';
$dev='Charles Aloaye , is a well known web Developer in Etsako East Edo State Agenebode where he hails from and in Africa based on the assistance he do render
to upcoming web developers,software designers.
He is currently one of the top moderator at a facebook group own by Asia people. C++,web and programmers
and another one own by his team NAIJA coders lab as the admin.
He Obtained his SSCE result at Success Secondary School Agenebode,one of outstanding high school in Etsako east axis.
he his currently looking forward to be admitted by one of Nigeria  Tertially Institution every Nigerian will dream of going.
you can follow him on some of his social media official account<br><p class="text-left">
instagram as <a href="http://Instagram.com/Sedenu Charles">Sedenu charles </a><br>
and on facebook as <a href="http://facebook.com/Sedenu.charles">Sedenucharles</a> also on <br>
twitter as <a href="http://twitter.com/sedenucharles">@sedenucharles</a></p>';
Echo $devimg .''. "<br>".$title.'<br>'.$dev;?>