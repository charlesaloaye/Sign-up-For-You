Hope you will find this helpful?
Is just a simple registration form built with bootstrap and php
For wide screen like desktop you can 
Change <div class="col-md-10">
To  <div class="col-md-12">
Or leave it like that for mobile 

Note this source code is free 
This was designed and developed by Naijacoderslab.blogspot.com 